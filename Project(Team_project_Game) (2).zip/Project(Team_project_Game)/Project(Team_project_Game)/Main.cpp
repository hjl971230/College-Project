#include "Header.h"
#include "Map.h"
#include "info.h"
#include "Player.h"
#include "UI.h"
int main()
{
	srand(time(NULL));
	UI UImanager;
	UImanager.Maintitle();
}